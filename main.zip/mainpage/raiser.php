	<?php	
						//Connection with database
						DEFINE ('DB_USER', 'root');
						DEFINE ('DB_PASSWORD', '1234');
						DEFINE ('DB_HOST', 'localhost');
						DEFINE ('DB_NAME', 'donation');

						$con = @mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME)
						OR die('Could not connect to MySQL: ' .mysqli_connect_error());
						
						//fetching values from form
						
						$fname = $_POST['firstname'];
						$lname = $_POST['lastname'];
						$email = $_POST['email'];
						$amount = $_POST['amount'];

						//inserting user data into datatable
						
						$reg = "insert into user_info(fname , lname , email , amount) values('".$fname."' , '".$lname."' , '".$email."' , '".$amount." ')";
						$result=@mysqli_query($con, $reg);
						
						if(!$result){
							echo "<script>alert('Unsuccess');</script>";
							header('location:mainindex.php');
						}
						elseif($result){
							echo "<script>alert('Success');</script>";
							header('location:mainindex.php');
						}
						
?>