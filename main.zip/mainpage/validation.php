<?php
	session_start();
	
	DEFINE ('DB_USER', 'root');
	DEFINE ('DB_PASSWORD', '1234');
	DEFINE ('DB_HOST', 'localhost');
	DEFINE ('DB_NAME', 'donation');

	$con = @mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME)
	OR die('Could not connect to MySQL: ' .mysqli_connect_error());
	
	$userid = $_POST['userid'];
	$pass = $_POST['password'];
	
	$s= "select * from admin where userid = '$userid' && password = '$pass'";
	
	$result = @mysqli_query($con, $s);
	
	$num = @mysqli_num_rows($result);
	
	if($num == 1)
	{
		$_SESSION['userid'] = $uname;
		header('location:dashboard.php');
	}
	else
	{
		header('location:index.php');
	}
?>