<?php	
		//Connection with database
		DEFINE ('DB_USER', 'root');
		DEFINE ('DB_PASSWORD', '1234');
		DEFINE ('DB_HOST', 'localhost');
		DEFINE ('DB_NAME', 'donation');

		$con = @mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME)
		OR die('Could not connect to MySQL: ' .mysqli_connect_error());
		
		//fetching values from form
		
		$org = $_POST['orgname'];
		$userid = $_POST['userid'];
		$email = $_POST['email'];
		$pass = $_POST['password'];
		
		//inserting user data into datatable
						

		$s= "select userid from admin where userid = '$userid'";
		$r=@mysqli_query($con, $s);
		$num = @mysqli_fetch_array($r);
		if($num[0] == $userid)
		{
			echo "<script>alert('Username taken');</script>";
		}
		else{
		$reg = "insert into admin(org , userid , password , email) values('".$org."' , '".$userid."' , '".$pass."' , '".$email."')";
		$result=@mysqli_query($con, $reg);
		}
		if(!$result){
			echo "<script>alert('Unsuccess');</script>";
			header('location:index.php');
		}
		elseif($result){
			echo "<script>alert('Success');</script>";
			header('location:index.php');
		}
?>